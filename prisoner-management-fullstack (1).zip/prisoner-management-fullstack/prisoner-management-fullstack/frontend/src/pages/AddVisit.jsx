import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import Alert from '../components/Alert.jsx';

export default function AddVisit() {
    const navigate = useNavigate();
    const [prisoners, setPrisoners] = useState([]);
    const [visitors,  setVisitors]  = useState([]);
    const [staff,     setStaff]     = useState([]);
    const [form, setForm] = useState({
        prisoner_id: '', visitor_id: '', staff_id: '', visit_date: '',
    });
    const [err, setErr] = useState('');

    useEffect(() => {
        Promise.all([api.get('/prisoners'), api.get('/visitors'), api.get('/staff')])
            .then(([p, v, s]) => { setPrisoners(p); setVisitors(v); setStaff(s); })
            .catch((e) => setErr(e.message));
    }, []);

    function update(field, value) {
        setForm((f) => ({ ...f, [field]: value }));
    }

    async function handleSubmit(e) {
        e.preventDefault();
        try {
            await api.post('/visits', form);
            navigate('/visits');
        } catch (e) {
            setErr(e.message);
        }
    }

    return (
        <div className="main-content">
            <div className="topbar">
                <h2><i className="bi bi-calendar-plus"></i> Log Visit</h2>
                <Link to="/visits" className="btn btn-secondary">
                    <i className="bi bi-arrow-left"></i> Back
                </Link>
            </div>

            <Alert message={err} type="danger" />

            <div className="card">
                <div className="card-header">Visit Details</div>
                <div className="card-body">
                    <form onSubmit={handleSubmit}>
                        <div className="row g-3">
                            <div className="col-md-4">
                                <label className="form-label">Prisoner</label>
                                <select className="form-select" required
                                    value={form.prisoner_id} onChange={(e) => update('prisoner_id', e.target.value)}>
                                    <option value="">-- Select Prisoner --</option>
                                    {prisoners.map((p) => (
                                        <option key={p.prisoner_id} value={p.prisoner_id}>{p.name}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md-4">
                                <label className="form-label">Visitor</label>
                                <select className="form-select" required
                                    value={form.visitor_id} onChange={(e) => update('visitor_id', e.target.value)}>
                                    <option value="">-- Select Visitor --</option>
                                    {visitors.map((v) => (
                                        <option key={v.visitor_id} value={v.visitor_id}>
                                            {v.name} ({v.relation})
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md-4">
                                <label className="form-label">Supervising Staff</label>
                                <select className="form-select" required
                                    value={form.staff_id} onChange={(e) => update('staff_id', e.target.value)}>
                                    <option value="">-- Select Staff --</option>
                                    {staff.map((s) => (
                                        <option key={s.staff_id} value={s.staff_id}>
                                            {s.name} - {s.role}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md-4">
                                <label className="form-label">Visit Date</label>
                                <input type="date" className="form-control" required
                                    value={form.visit_date} onChange={(e) => update('visit_date', e.target.value)} />
                            </div>
                        </div>

                        <div className="mt-4">
                            <button type="submit" className="btn btn-primary">
                                <i className="bi bi-check-lg"></i> Log Visit
                            </button>
                            <Link to="/visits" className="btn btn-light ms-2">Cancel</Link>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}
