import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import Alert from '../components/Alert.jsx';

export default function Visits() {
    const [list, setList] = useState([]);
    const [err, setErr] = useState('');

    useEffect(() => {
        api.get('/visits').then(setList).catch((e) => setErr(e.message));
    }, []);

    return (
        <div className="main-content">
            <div className="topbar">
                <h2><i className="bi bi-calendar-check"></i> Visits</h2>
                <Link to="/visits/add" className="btn btn-primary">
                    <i className="bi bi-plus-lg"></i> Log Visit
                </Link>
            </div>

            <Alert message={err} type="danger" />

            <div className="card">
                <div className="card-header">All Visits</div>
                <div className="card-body p-0">
                    <div className="table-responsive">
                        <table className="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th><th>Prisoner</th><th>Visitor</th>
                                    <th>Relation</th><th>Supervised By</th><th>Visit Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {list.length === 0 && (
                                    <tr><td colSpan="6" className="text-center py-4 text-muted">No visits recorded.</td></tr>
                                )}
                                {list.map((v) => (
                                    <tr key={v.visit_id}>
                                        <td>{v.visit_id}</td>
                                        <td>{v.prisoner_name}</td>
                                        <td>{v.visitor_name}</td>
                                        <td>{v.relation}</td>
                                        <td>{v.staff_name} ({v.role})</td>
                                        <td>{v.visit_date?.slice(0, 10)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
