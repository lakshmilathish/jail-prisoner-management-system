import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import Alert from '../components/Alert.jsx';

export default function AddPrisoner() {
    const navigate = useNavigate();
    const [jails, setJails]   = useState([]);
    const [crimes, setCrimes] = useState([]);
    const [cells, setCells]   = useState([]);
    const [err, setErr]       = useState('');
    const [form, setForm] = useState({
        name: '', age: '', gender: '', entry_date: '',
        jail_id: '', crime_id: '', cell_id: '',
    });

    useEffect(() => {
        Promise.all([api.get('/jails'), api.get('/crimes'), api.get('/cells')])
            .then(([j, c, ce]) => { setJails(j); setCrimes(c); setCells(ce); })
            .catch((e) => setErr(e.message));
    }, []);

    function update(field, value) {
        setForm((f) => ({ ...f, [field]: value }));
    }

    async function handleSubmit(e) {
        e.preventDefault();
        try {
            await api.post('/prisoners', form);
            navigate('/prisoners');
        } catch (e) {
            setErr(e.message);
        }
    }

    return (
        <div className="main-content">
            <div className="topbar">
                <h2><i className="bi bi-person-plus"></i> Add Prisoner</h2>
                <Link to="/prisoners" className="btn btn-secondary">
                    <i className="bi bi-arrow-left"></i> Back
                </Link>
            </div>

            <Alert message={err} type="danger" />

            <div className="card">
                <div className="card-header">Prisoner Details</div>
                <div className="card-body">
                    <form onSubmit={handleSubmit}>
                        <div className="row g-3">
                            <div className="col-md-6">
                                <label className="form-label">Full Name</label>
                                <input type="text" className="form-control" required
                                    value={form.name} onChange={(e) => update('name', e.target.value)} />
                            </div>
                            <div className="col-md-3">
                                <label className="form-label">Age</label>
                                <input type="number" className="form-control" min="1" max="120" required
                                    value={form.age} onChange={(e) => update('age', e.target.value)} />
                            </div>
                            <div className="col-md-3">
                                <label className="form-label">Gender</label>
                                <select className="form-select" required
                                    value={form.gender} onChange={(e) => update('gender', e.target.value)}>
                                    <option value="">-- Select --</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div className="col-md-4">
                                <label className="form-label">Entry Date</label>
                                <input type="date" className="form-control" required
                                    value={form.entry_date} onChange={(e) => update('entry_date', e.target.value)} />
                            </div>
                            <div className="col-md-4">
                                <label className="form-label">Central Jail</label>
                                <select className="form-select" required
                                    value={form.jail_id} onChange={(e) => update('jail_id', e.target.value)}>
                                    <option value="">-- Select Jail --</option>
                                    {jails.map((j) => (
                                        <option key={j.jail_id} value={j.jail_id}>
                                            {j.jail_name} ({j.location})
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md-4">
                                <label className="form-label">Crime</label>
                                <select className="form-select" required
                                    value={form.crime_id} onChange={(e) => update('crime_id', e.target.value)}>
                                    <option value="">-- Select Crime --</option>
                                    {crimes.map((c) => (
                                        <option key={c.crime_id} value={c.crime_id}>{c.crime_type}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md-6">
                                <label className="form-label">Cell</label>
                                <select className="form-select" required
                                    value={form.cell_id} onChange={(e) => update('cell_id', e.target.value)}>
                                    <option value="">-- Select Cell --</option>
                                    {cells.map((ce) => (
                                        <option key={ce.cell_id} value={ce.cell_id}>
                                            Block {ce.block} (Capacity: {ce.capacity}, Occupied: {ce.current_occupancy})
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>

                        <div className="mt-4">
                            <button type="submit" className="btn btn-primary">
                                <i className="bi bi-check-lg"></i> Save Prisoner
                            </button>
                            <Link to="/prisoners" className="btn btn-light ms-2">Cancel</Link>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}
