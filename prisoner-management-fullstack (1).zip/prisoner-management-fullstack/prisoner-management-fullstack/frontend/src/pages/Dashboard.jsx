import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function Dashboard() {
    const [stats, setStats] = useState({ prisoners: 0, visitors: 0, staff: 0, visits: 0, punishments: 0 });
    const [recentPrisoners, setRecentPrisoners] = useState([]);
    const [recentVisits, setRecentVisits] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        Promise.all([api.get('/dashboard'), api.get('/prisoners'), api.get('/visits')])
            .then(([s, p, v]) => {
                setStats(s);
                setRecentPrisoners(p.slice(0, 5));
                setRecentVisits(v.slice(0, 5));
            })
            .catch((e) => setError(e.message));
    }, []);

    const cards = [
        { label: 'Prisoners',     value: stats.prisoners,   icon: 'person-badge',     color: 'text-danger'    },
        { label: 'Punishments',   value: stats.punishments, icon: 'hammer',           color: 'text-warning'   },
        { label: 'Visitors',      value: stats.visitors,    icon: 'people',           color: 'text-primary'   },
        { label: 'Staff',         value: stats.staff,       icon: 'person-workspace', color: 'text-success'   },
        { label: 'Visits Logged', value: stats.visits,      icon: 'calendar-check',   color: 'text-secondary' },
    ];

    return (
        <div className="main-content">
            <div className="topbar">
                <h2><i className="bi bi-speedometer2"></i> Dashboard</h2>
                <span className="text-muted">{new Date().toDateString()}</span>
            </div>

            {error && <div className="alert alert-danger">{error}</div>}

            <div className="row g-4 mb-4">
                {cards.map((c) => (
                    <div className="col-md-6 col-lg" key={c.label}>
                        <div className="card stat-card">
                            <div className="card-body d-flex justify-content-between align-items-center">
                                <div>
                                    <div className="stat-label">{c.label}</div>
                                    <div className="stat-value">{c.value}</div>
                                </div>
                                <i className={`bi bi-${c.icon} stat-icon ${c.color}`}></i>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="row g-4">
                <div className="col-md-6">
                    <div className="card">
                        <div className="card-header">Recent Prisoners</div>
                        <div className="card-body p-0">
                            <table className="table table-striped mb-0">
                                <thead><tr><th>ID</th><th>Name</th><th>Crime</th><th>Entry Date</th></tr></thead>
                                <tbody>
                                    {recentPrisoners.map((p) => (
                                        <tr key={p.prisoner_id}>
                                            <td>{p.prisoner_id}</td>
                                            <td>{p.name}</td>
                                            <td>{p.crime_type}</td>
                                            <td>{p.entry_date?.slice(0, 10)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div className="col-md-6">
                    <div className="card">
                        <div className="card-header">Recent Visits</div>
                        <div className="card-body p-0">
                            <table className="table table-striped mb-0">
                                <thead><tr><th>ID</th><th>Prisoner</th><th>Visitor</th><th>Date</th></tr></thead>
                                <tbody>
                                    {recentVisits.map((v) => (
                                        <tr key={v.visit_id}>
                                            <td>{v.visit_id}</td>
                                            <td>{v.prisoner_name}</td>
                                            <td>{v.visitor_name}</td>
                                            <td>{v.visit_date?.slice(0, 10)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
