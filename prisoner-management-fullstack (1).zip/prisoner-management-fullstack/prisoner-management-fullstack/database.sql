-- Jail Prisoner Management System (Full-Stack)
-- MySQL Database Schema

CREATE DATABASE IF NOT EXISTS jailprisoner
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE jailprisoner;

DROP TABLE IF EXISTS visit;
DROP TABLE IF EXISTS punishment;
DROP TABLE IF EXISTS visitor;
DROP TABLE IF EXISTS prisoner;
DROP TABLE IF EXISTS staff;
DROP TABLE IF EXISTS cell;
DROP TABLE IF EXISTS crime;
DROP TABLE IF EXISTS central_jail;

CREATE TABLE central_jail (
    jail_id   INT AUTO_INCREMENT PRIMARY KEY,
    jail_name VARCHAR(100) NOT NULL,
    location  VARCHAR(150) NOT NULL
);

CREATE TABLE crime (
    crime_id    INT AUTO_INCREMENT PRIMARY KEY,
    crime_type  VARCHAR(100) NOT NULL,
    description TEXT
);

CREATE TABLE cell (
    cell_id           INT AUTO_INCREMENT PRIMARY KEY,
    block             VARCHAR(20) NOT NULL,
    capacity          INT NOT NULL,
    current_occupancy INT NOT NULL DEFAULT 0
);

CREATE TABLE staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    name     VARCHAR(100) NOT NULL,
    role     VARCHAR(50)  NOT NULL,
    shift    VARCHAR(20)  NOT NULL
);

CREATE TABLE prisoner (
    prisoner_id INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    age         INT NOT NULL,
    gender      ENUM('Male','Female','Other') NOT NULL,
    entry_date  DATE NOT NULL,
    jail_id     INT NOT NULL,
    crime_id    INT NOT NULL,
    cell_id     INT NOT NULL,
    FOREIGN KEY (jail_id)  REFERENCES central_jail(jail_id),
    FOREIGN KEY (crime_id) REFERENCES crime(crime_id),
    FOREIGN KEY (cell_id)  REFERENCES cell(cell_id)
);

CREATE TABLE punishment (
    punishment_id INT AUTO_INCREMENT PRIMARY KEY,
    prisoner_id   INT NOT NULL,
    years         INT NOT NULL,
    start_date    DATE NOT NULL,
    end_date      DATE NOT NULL,
    FOREIGN KEY (prisoner_id) REFERENCES prisoner(prisoner_id) ON DELETE CASCADE
);

CREATE TABLE visitor (
    visitor_id INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    relation   VARCHAR(50)  NOT NULL,
    phone      VARCHAR(20)  NOT NULL
);

CREATE TABLE visit (
    visit_id    INT AUTO_INCREMENT PRIMARY KEY,
    prisoner_id INT NOT NULL,
    visitor_id  INT NOT NULL,
    staff_id    INT NOT NULL,
    visit_date  DATE NOT NULL,
    FOREIGN KEY (prisoner_id) REFERENCES prisoner(prisoner_id) ON DELETE CASCADE,
    FOREIGN KEY (visitor_id)  REFERENCES visitor(visitor_id),
    FOREIGN KEY (staff_id)    REFERENCES staff(staff_id)
);

-- ---------- Sample Data ----------

INSERT INTO central_jail (jail_name, location) VALUES
('Central Jail Alpha', 'New Delhi'),
('Central Jail Beta',  'Mumbai'),
('Central Jail Gamma', 'Chennai');

INSERT INTO crime (crime_type, description) VALUES
('Theft',    'Stealing of property'),
('Assault',  'Physical attack on another person'),
('Fraud',    'Deceptive practices for financial gain'),
('Burglary', 'Unlawful entry into a building');

INSERT INTO cell (block, capacity, current_occupancy) VALUES
('A-1', 4, 2),
('A-2', 4, 1),
('B-1', 6, 3),
('B-2', 6, 0);

INSERT INTO staff (name, role, shift) VALUES
('Rajesh Kumar', 'Warden',     'Morning'),
('Anita Sharma', 'Officer',    'Evening'),
('Vikram Singh', 'Guard',      'Night'),
('Priya Patel',  'Supervisor', 'Morning');

INSERT INTO prisoner (name, age, gender, entry_date, jail_id, crime_id, cell_id) VALUES
('Amit Verma',   28, 'Male',   '2025-01-15', 1, 1, 1),
('Suresh Mehta', 35, 'Male',   '2025-02-10', 1, 2, 1),
('Ravi Yadav',   42, 'Male',   '2025-03-05', 2, 3, 3),
('Neha Joshi',   30, 'Female', '2025-04-12', 2, 1, 2);

INSERT INTO punishment (prisoner_id, years, start_date, end_date) VALUES
(1, 2, '2025-01-15', '2027-01-15'),
(2, 5, '2025-02-10', '2030-02-10'),
(3, 3, '2025-03-05', '2028-03-05'),
(4, 1, '2025-04-12', '2026-04-12');

INSERT INTO visitor (name, relation, phone) VALUES
('Sunita Verma', 'Wife',    '9876543210'),
('Ramesh Mehta', 'Brother', '9876543211'),
('Kavita Yadav', 'Mother',  '9876543212'),
('Rohit Joshi',  'Husband', '9876543213');

INSERT INTO visit (prisoner_id, visitor_id, staff_id, visit_date) VALUES
(1, 1, 2, '2025-04-01'),
(2, 2, 3, '2025-04-05'),
(3, 3, 1, '2025-04-10'),
(4, 4, 4, '2025-04-15');
