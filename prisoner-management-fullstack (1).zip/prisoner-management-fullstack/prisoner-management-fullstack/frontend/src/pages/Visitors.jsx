import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import Alert from '../components/Alert.jsx';

export default function Visitors() {
    const [list, setList] = useState([]);
    const [err, setErr] = useState('');

    useEffect(() => {
        api.get('/visitors').then(setList).catch((e) => setErr(e.message));
    }, []);

    return (
        <div className="main-content">
            <div className="topbar">
                <h2><i className="bi bi-people"></i> Visitors</h2>
                <Link to="/visitors/add" className="btn btn-primary">
                    <i className="bi bi-plus-lg"></i> Add Visitor
                </Link>
            </div>

            <Alert message={err} type="danger" />

            <div className="card">
                <div className="card-header">All Visitors</div>
                <div className="card-body p-0">
                    <div className="table-responsive">
                        <table className="table table-hover mb-0">
                            <thead>
                                <tr><th>ID</th><th>Name</th><th>Relation</th><th>Phone</th></tr>
                            </thead>
                            <tbody>
                                {list.length === 0 && (
                                    <tr><td colSpan="4" className="text-center py-4 text-muted">No visitors found.</td></tr>
                                )}
                                {list.map((v) => (
                                    <tr key={v.visitor_id}>
                                        <td>{v.visitor_id}</td>
                                        <td>{v.name}</td>
                                        <td>{v.relation}</td>
                                        <td>{v.phone}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
