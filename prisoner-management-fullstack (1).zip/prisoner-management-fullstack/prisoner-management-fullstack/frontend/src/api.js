// Simple API helper using fetch()
const API_URL = 'http://localhost:5000';

async function request(path, options = {}) {
    const res = await fetch(`${API_URL}${path}`, {
        headers: { 'Content-Type': 'application/json' },
        ...options,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
        throw new Error(data.error || `Request failed: ${res.status}`);
    }
    return data;
}

export const api = {
    get:  (path)        => request(path),
    post: (path, body)  => request(path, { method: 'POST',   body: JSON.stringify(body) }),
    del:  (path)        => request(path, { method: 'DELETE' }),
};
