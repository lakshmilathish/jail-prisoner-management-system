import { useEffect, useState } from 'react';
import { api } from '../api.js';
import Alert from '../components/Alert.jsx';

export default function Staff() {
    const [list, setList] = useState([]);
    const [err, setErr] = useState('');

    useEffect(() => {
        api.get('/staff').then(setList).catch((e) => setErr(e.message));
    }, []);

    return (
        <div className="main-content">
            <div className="topbar">
                <h2><i className="bi bi-person-workspace"></i> Staff</h2>
            </div>

            <Alert message={err} type="danger" />

            <div className="card">
                <div className="card-header">All Staff Members</div>
                <div className="card-body p-0">
                    <div className="table-responsive">
                        <table className="table table-hover mb-0">
                            <thead>
                                <tr><th>ID</th><th>Name</th><th>Role</th><th>Shift</th></tr>
                            </thead>
                            <tbody>
                                {list.length === 0 && (
                                    <tr><td colSpan="4" className="text-center py-4 text-muted">No staff found.</td></tr>
                                )}
                                {list.map((s) => (
                                    <tr key={s.staff_id}>
                                        <td>{s.staff_id}</td>
                                        <td>{s.name}</td>
                                        <td>{s.role}</td>
                                        <td>{s.shift}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
