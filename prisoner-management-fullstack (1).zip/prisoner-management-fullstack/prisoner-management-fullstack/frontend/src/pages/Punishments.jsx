import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import Alert from '../components/Alert.jsx';

export default function Punishments() {
    const [list, setList] = useState([]);
    const [msg, setMsg] = useState('');
    const [err, setErr] = useState('');

    function load() {
        api.get('/punishments').then(setList).catch((e) => setErr(e.message));
    }

    useEffect(load, []);

    async function handleDelete(id) {
        if (!confirm('Delete this punishment record?')) return;
        try {
            const r = await api.del(`/punishments/${id}`);
            setMsg(r.message);
            setErr('');
            load();
        } catch (e) {
            setErr(e.message);
        }
    }

    return (
        <div className="main-content">
            <div className="topbar">
                <h2><i className="bi bi-hammer"></i> Punishments</h2>
                <Link to="/punishments/add" className="btn btn-primary">
                    <i className="bi bi-plus-lg"></i> Add Punishment
                </Link>
            </div>

            <Alert message={msg} type="success" />
            <Alert message={err} type="danger" />

            <div className="card">
                <div className="card-header">All Punishments</div>
                <div className="card-body p-0">
                    <div className="table-responsive">
                        <table className="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Prisoner</th>
                                    <th>Years</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {list.length === 0 && (
                                    <tr><td colSpan="6" className="text-center py-4 text-muted">No punishments found.</td></tr>
                                )}
                                {list.map((pu) => (
                                    <tr key={pu.punishment_id}>
                                        <td>{pu.punishment_id}</td>
                                        <td>{pu.prisoner_name}</td>
                                        <td>
                                            <span className="badge bg-warning text-dark">
                                                {pu.years} {pu.years === 1 ? 'year' : 'years'}
                                            </span>
                                        </td>
                                        <td>{pu.start_date?.slice(0, 10)}</td>
                                        <td>{pu.end_date?.slice(0, 10)}</td>
                                        <td>
                                            <button
                                                className="btn btn-sm btn-danger"
                                                onClick={() => handleDelete(pu.punishment_id)}
                                            >
                                                <i className="bi bi-trash"></i> Delete
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
