import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import Alert from '../components/Alert.jsx';

function addYears(dateStr, years) {
    if (!dateStr || !years) return '';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '';
    d.setFullYear(d.getFullYear() + Number(years));
    return d.toISOString().slice(0, 10);
}

export default function AddPunishment() {
    const navigate = useNavigate();
    const [prisoners, setPrisoners] = useState([]);
    const [err, setErr] = useState('');
    const [form, setForm] = useState({
        prisoner_id: '',
        years: '',
        start_date: '',
        end_date: '',
    });

    useEffect(() => {
        api.get('/prisoners').then(setPrisoners).catch((e) => setErr(e.message));
    }, []);

    function update(field, value) {
        setForm((f) => {
            const next = { ...f, [field]: value };
            // Auto-calculate end_date if user has set start_date + years
            if ((field === 'start_date' || field === 'years') && next.start_date && next.years) {
                next.end_date = addYears(next.start_date, next.years);
            }
            return next;
        });
    }

    const previewEnd = useMemo(
        () => (form.start_date && form.years ? addYears(form.start_date, form.years) : ''),
        [form.start_date, form.years]
    );

    async function handleSubmit(e) {
        e.preventDefault();
        try {
            await api.post('/punishments', form);
            navigate('/punishments');
        } catch (e) {
            setErr(e.message);
        }
    }

    return (
        <div className="main-content">
            <div className="topbar">
                <h2><i className="bi bi-plus-square"></i> Add Punishment</h2>
                <Link to="/punishments" className="btn btn-secondary">
                    <i className="bi bi-arrow-left"></i> Back
                </Link>
            </div>

            <Alert message={err} type="danger" />

            <div className="card">
                <div className="card-header">Punishment Details</div>
                <div className="card-body">
                    <form onSubmit={handleSubmit}>
                        <div className="row g-3">
                            <div className="col-md-6">
                                <label className="form-label">Prisoner</label>
                                <select className="form-select" required
                                    value={form.prisoner_id}
                                    onChange={(e) => update('prisoner_id', e.target.value)}>
                                    <option value="">-- Select Prisoner --</option>
                                    {prisoners.map((p) => (
                                        <option key={p.prisoner_id} value={p.prisoner_id}>
                                            {p.name} (ID: {p.prisoner_id})
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md-6">
                                <label className="form-label">Years of Punishment</label>
                                <input type="number" className="form-control" min="1" max="100" required
                                    value={form.years}
                                    onChange={(e) => update('years', e.target.value)} />
                            </div>
                            <div className="col-md-6">
                                <label className="form-label">Start Date</label>
                                <input type="date" className="form-control" required
                                    value={form.start_date}
                                    onChange={(e) => update('start_date', e.target.value)} />
                            </div>
                            <div className="col-md-6">
                                <label className="form-label">End Date</label>
                                <input type="date" className="form-control" required
                                    value={form.end_date}
                                    onChange={(e) => update('end_date', e.target.value)} />
                                {previewEnd && (
                                    <div className="form-text">
                                        Auto-calculated from start date + years: <strong>{previewEnd}</strong>. You can override.
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="mt-4">
                            <button type="submit" className="btn btn-primary">
                                <i className="bi bi-check-lg"></i> Save Punishment
                            </button>
                            <Link to="/punishments" className="btn btn-light ms-2">Cancel</Link>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}
