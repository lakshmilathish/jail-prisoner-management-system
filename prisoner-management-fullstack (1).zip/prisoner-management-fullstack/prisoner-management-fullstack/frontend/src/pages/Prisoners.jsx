import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import Alert from '../components/Alert.jsx';

export default function Prisoners() {
    const [list, setList] = useState([]);
    const [msg, setMsg] = useState('');
    const [err, setErr] = useState('');

    function load() {
        api.get('/prisoners').then(setList).catch((e) => setErr(e.message));
    }

    useEffect(load, []);

    async function handleDelete(id) {
        if (!confirm('Delete this prisoner?')) return;
        try {
            const r = await api.del(`/prisoners/${id}`);
            setMsg(r.message);
            setErr('');
            load();
        } catch (e) {
            setErr(e.message);
        }
    }

    return (
        <div className="main-content">
            <div className="topbar">
                <h2><i className="bi bi-person-badge"></i> Prisoners</h2>
                <Link to="/prisoners/add" className="btn btn-primary">
                    <i className="bi bi-plus-lg"></i> Add Prisoner
                </Link>
            </div>

            <Alert message={msg} type="success" />
            <Alert message={err} type="danger" />

            <div className="card">
                <div className="card-header">All Prisoners</div>
                <div className="card-body p-0">
                    <div className="table-responsive">
                        <table className="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th><th>Name</th><th>Age</th><th>Gender</th>
                                    <th>Entry Date</th><th>Jail</th><th>Crime</th>
                                    <th>Cell</th><th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {list.length === 0 && (
                                    <tr><td colSpan="9" className="text-center py-4 text-muted">No prisoners found.</td></tr>
                                )}
                                {list.map((p) => (
                                    <tr key={p.prisoner_id}>
                                        <td>{p.prisoner_id}</td>
                                        <td>{p.name}</td>
                                        <td>{p.age}</td>
                                        <td>{p.gender}</td>
                                        <td>{p.entry_date?.slice(0, 10)}</td>
                                        <td>{p.jail_name}</td>
                                        <td>{p.crime_type}</td>
                                        <td>{p.block}</td>
                                        <td>
                                            <button
                                                className="btn btn-sm btn-danger"
                                                onClick={() => handleDelete(p.prisoner_id)}
                                            >
                                                <i className="bi bi-trash"></i> Delete
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
