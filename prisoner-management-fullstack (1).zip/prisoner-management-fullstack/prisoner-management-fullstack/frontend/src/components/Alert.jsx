export default function Alert({ message, type = 'success' }) {
    if (!message) return null;
    return (
        <div className={`alert alert-${type}`} role="alert">
            {message}
        </div>
    );
}
