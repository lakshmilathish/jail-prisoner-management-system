// Jail Prisoner Management System - Express + MySQL backend

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// ---------- MySQL Connection Pool ----------
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'jailprisoner',
    waitForConnections: true,
    connectionLimit: 10,
});

// Quick connection check on startup
(async () => {
    try {
        const conn = await pool.getConnection();
        console.log(`MySQL connected to "${process.env.DB_NAME || 'jailprisoner'}"`);
        conn.release();
    } catch (err) {
        console.error('MySQL connection failed:', err.message);
    }
})();

// ---------- Health ----------
app.get('/', (req, res) => {
    res.json({ message: 'JPMS API is running', version: '1.0.0' });
});

// ---------- Dashboard summary ----------
app.get('/dashboard', async (req, res) => {
    try {
        const [[{ prisoners }]] = await pool.query('SELECT COUNT(*) AS prisoners FROM prisoner');
        const [[{ visitors }]] = await pool.query('SELECT COUNT(*) AS visitors FROM visitor');
        const [[{ staff }]]    = await pool.query('SELECT COUNT(*) AS staff FROM staff');
        const [[{ visits }]]      = await pool.query('SELECT COUNT(*) AS visits FROM visit');
        const [[{ punishments }]] = await pool.query('SELECT COUNT(*) AS punishments FROM punishment');
        res.json({ prisoners, visitors, staff, visits, punishments });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ---------- Lookup tables (for dropdowns) ----------
app.get('/jails', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM central_jail ORDER BY jail_name');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/crimes', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM crime ORDER BY crime_type');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/cells', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM cell ORDER BY block');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/staff', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM staff ORDER BY name');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// ---------- PRISONERS ----------
app.get('/prisoners', async (req, res) => {
    try {
        const sql = `
            SELECT p.prisoner_id, p.name, p.age, p.gender, p.entry_date,
                   p.jail_id, p.crime_id, p.cell_id,
                   j.jail_name, c.crime_type, ce.block
            FROM prisoner p
            JOIN central_jail j ON p.jail_id  = j.jail_id
            JOIN crime c        ON p.crime_id = c.crime_id
            JOIN cell ce        ON p.cell_id  = ce.cell_id
            ORDER BY p.prisoner_id DESC`;
        const [rows] = await pool.query(sql);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/prisoners', async (req, res) => {
    try {
        const { name, age, gender, entry_date, jail_id, crime_id, cell_id } = req.body;
        if (!name || !age || !gender || !entry_date || !jail_id || !crime_id || !cell_id) {
            return res.status(400).json({ error: 'All fields are required' });
        }
        const [result] = await pool.query(
            `INSERT INTO prisoner (name, age, gender, entry_date, jail_id, crime_id, cell_id)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [name, age, gender, entry_date, jail_id, crime_id, cell_id]
        );
        res.status(201).json({ message: 'Prisoner added successfully', id: result.insertId });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/prisoners/:id', async (req, res) => {
    try {
        const [result] = await pool.query('DELETE FROM prisoner WHERE prisoner_id = ?', [req.params.id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Prisoner not found' });
        }
        res.json({ message: 'Prisoner deleted successfully' });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// ---------- PUNISHMENTS ----------
app.get('/punishments', async (req, res) => {
    try {
        const sql = `
            SELECT pu.punishment_id, pu.prisoner_id, pu.years, pu.start_date, pu.end_date,
                   p.name AS prisoner_name
            FROM punishment pu
            JOIN prisoner p ON pu.prisoner_id = p.prisoner_id
            ORDER BY pu.punishment_id DESC`;
        const [rows] = await pool.query(sql);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/punishments', async (req, res) => {
    try {
        const { prisoner_id, years, start_date, end_date } = req.body;
        if (!prisoner_id || !years || !start_date || !end_date) {
            return res.status(400).json({ error: 'All fields are required' });
        }
        const [result] = await pool.query(
            `INSERT INTO punishment (prisoner_id, years, start_date, end_date)
             VALUES (?, ?, ?, ?)`,
            [prisoner_id, years, start_date, end_date]
        );
        res.status(201).json({ message: 'Punishment added successfully', id: result.insertId });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/punishments/:id', async (req, res) => {
    try {
        const [result] = await pool.query(
            'DELETE FROM punishment WHERE punishment_id = ?',
            [req.params.id]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Punishment not found' });
        }
        res.json({ message: 'Punishment deleted successfully' });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// ---------- VISITORS ----------
app.get('/visitors', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM visitor ORDER BY visitor_id DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/visitors', async (req, res) => {
    try {
        const { name, relation, phone } = req.body;
        if (!name || !relation || !phone) {
            return res.status(400).json({ error: 'All fields are required' });
        }
        const [result] = await pool.query(
            'INSERT INTO visitor (name, relation, phone) VALUES (?, ?, ?)',
            [name, relation, phone]
        );
        res.status(201).json({ message: 'Visitor added successfully', id: result.insertId });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// ---------- VISITS ----------
app.get('/visits', async (req, res) => {
    try {
        const sql = `
            SELECT v.visit_id, v.visit_date,
                   v.prisoner_id, v.visitor_id, v.staff_id,
                   p.name  AS prisoner_name,
                   vs.name AS visitor_name, vs.relation,
                   s.name  AS staff_name, s.role
            FROM visit v
            JOIN prisoner p  ON v.prisoner_id = p.prisoner_id
            JOIN visitor vs  ON v.visitor_id  = vs.visitor_id
            JOIN staff s     ON v.staff_id    = s.staff_id
            ORDER BY v.visit_date DESC`;
        const [rows] = await pool.query(sql);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/visits', async (req, res) => {
    try {
        const { prisoner_id, visitor_id, staff_id, visit_date } = req.body;
        if (!prisoner_id || !visitor_id || !staff_id || !visit_date) {
            return res.status(400).json({ error: 'All fields are required' });
        }
        const [result] = await pool.query(
            'INSERT INTO visit (prisoner_id, visitor_id, staff_id, visit_date) VALUES (?, ?, ?, ?)',
            [prisoner_id, visitor_id, staff_id, visit_date]
        );
        res.status(201).json({ message: 'Visit logged successfully', id: result.insertId });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// ---------- Start ----------
app.listen(PORT, () => {
    console.log(`JPMS API server running on http://localhost:${PORT}`);
});
