import { NavLink } from 'react-router-dom';

const links = [
    { to: '/',          icon: 'speedometer2',     label: 'Dashboard' },
    { to: '/prisoners',   icon: 'person-badge',     label: 'Prisoners' },
    { to: '/punishments', icon: 'hammer',           label: 'Punishments' },
    { to: '/visitors',    icon: 'people',           label: 'Visitors' },
    { to: '/visits',    icon: 'calendar-check',   label: 'Visits' },
    { to: '/staff',     icon: 'person-workspace', label: 'Staff' },
];

export default function Sidebar() {
    return (
        <div className="sidebar">
            <h4><i className="bi bi-shield-lock-fill"></i> JPMS</h4>
            {links.map((l) => (
                <NavLink key={l.to} to={l.to} end={l.to === '/'}>
                    <i className={`bi bi-${l.icon}`}></i> &nbsp; {l.label}
                </NavLink>
            ))}
        </div>
    );
}
