# Jail Prisoner Management System — Full-Stack

Full-stack version of JPMS using **React + Express + MySQL**.

## Stack
- **Frontend:** React 18 + Vite + React Router + Bootstrap 5
- **Backend:** Node.js + Express
- **Database:** MySQL (via `mysql2`)

## Folder Structure
```
prisoner-management-fullstack/
├── backend/
│   ├── server.js          # Express server + REST APIs
│   ├── package.json
│   └── .env.example       # Copy to .env and edit
├── frontend/
│   ├── index.html
│   ├── vite.config.js
│   ├── package.json
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── api.js         # fetch() wrapper
│       ├── index.css
│       ├── components/
│       │   ├── Sidebar.jsx
│       │   └── Alert.jsx
│       └── pages/
│           ├── Dashboard.jsx
│           ├── Prisoners.jsx     /  AddPrisoner.jsx
│           ├── Punishments.jsx   /  AddPunishment.jsx
│           ├── Visitors.jsx      /  AddVisitor.jsx
│           ├── Visits.jsx        /  AddVisit.jsx
│           └── Staff.jsx
└── database.sql           # MySQL schema + sample data
```

## REST API Endpoints

| Method | Endpoint           | Description                     |
| ------ | ------------------ | ------------------------------- |
| GET    | `/dashboard`       | Totals for cards                |
| GET    | `/jails`           | All central jails (dropdown)    |
| GET    | `/crimes`          | All crimes (dropdown)           |
| GET    | `/cells`           | All cells (dropdown)            |
| GET    | `/staff`           | All staff (dropdown / list)     |
| GET    | `/prisoners`       | List prisoners (with joins)     |
| POST   | `/prisoners`       | Add a prisoner                  |
| DELETE | `/prisoners/:id`   | Delete a prisoner               |
| GET    | `/punishments`     | List punishments (with prisoner)|
| POST   | `/punishments`     | Add a punishment                |
| DELETE | `/punishments/:id` | Delete a punishment             |
| GET    | `/visitors`        | List visitors                   |
| POST   | `/visitors`        | Add a visitor                   |
| GET    | `/visits`          | List visits (with joins)        |
| POST   | `/visits`          | Log a new visit                 |

## Setup

### 1. Create the MySQL database

Open phpMyAdmin (or MySQL CLI) and import `database.sql`. It creates the database `jailprisoner`, all tables (including `punishment`), and inserts sample data.

```sql
SOURCE /path/to/database.sql;
```

### 2. Run the backend

```bash
cd backend
cp .env.example .env       # Edit DB credentials
npm install
npm run dev                # Server on http://localhost:5000
```

`.env` defaults match XAMPP (`root` / no password).

### 3. Run the frontend

```bash
cd frontend
npm install
npm run dev                # App on http://localhost:5173
```

Open <http://localhost:5173> in your browser.

## Notes
- The backend uses a `mysql2` connection pool with promise-style queries.
- The frontend uses `fetch()` with a tiny helper in `src/api.js` (`api.get`, `api.post`, `api.del`).
- Foreign keys are populated using `<select>` dropdowns loaded from `/jails`, `/crimes`, `/cells`, `/staff`, `/prisoners`, `/visitors`.
- Success/error messages are shown via Bootstrap alerts.
- CORS is enabled so the React dev server (port 5173) can call the API (port 5000).
- The original PHP version is unchanged in `../prisoner-management/`.
