import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import Alert from '../components/Alert.jsx';

export default function AddVisitor() {
    const navigate = useNavigate();
    const [form, setForm] = useState({ name: '', relation: '', phone: '' });
    const [err, setErr] = useState('');

    function update(field, value) {
        setForm((f) => ({ ...f, [field]: value }));
    }

    async function handleSubmit(e) {
        e.preventDefault();
        try {
            await api.post('/visitors', form);
            navigate('/visitors');
        } catch (e) {
            setErr(e.message);
        }
    }

    return (
        <div className="main-content">
            <div className="topbar">
                <h2><i className="bi bi-person-plus"></i> Add Visitor</h2>
                <Link to="/visitors" className="btn btn-secondary">
                    <i className="bi bi-arrow-left"></i> Back
                </Link>
            </div>

            <Alert message={err} type="danger" />

            <div className="card">
                <div className="card-header">Visitor Details</div>
                <div className="card-body">
                    <form onSubmit={handleSubmit}>
                        <div className="row g-3">
                            <div className="col-md-6">
                                <label className="form-label">Full Name</label>
                                <input type="text" className="form-control" required
                                    value={form.name} onChange={(e) => update('name', e.target.value)} />
                            </div>
                            <div className="col-md-3">
                                <label className="form-label">Relation</label>
                                <input type="text" className="form-control" placeholder="e.g. Brother" required
                                    value={form.relation} onChange={(e) => update('relation', e.target.value)} />
                            </div>
                            <div className="col-md-3">
                                <label className="form-label">Phone</label>
                                <input type="text" className="form-control" maxLength="20" required
                                    value={form.phone} onChange={(e) => update('phone', e.target.value)} />
                            </div>
                        </div>

                        <div className="mt-4">
                            <button type="submit" className="btn btn-primary">
                                <i className="bi bi-check-lg"></i> Save Visitor
                            </button>
                            <Link to="/visitors" className="btn btn-light ms-2">Cancel</Link>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}
