import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Prisoners from './pages/Prisoners.jsx';
import AddPrisoner from './pages/AddPrisoner.jsx';
import Punishments from './pages/Punishments.jsx';
import AddPunishment from './pages/AddPunishment.jsx';
import Visitors from './pages/Visitors.jsx';
import AddVisitor from './pages/AddVisitor.jsx';
import Visits from './pages/Visits.jsx';
import AddVisit from './pages/AddVisit.jsx';
import Staff from './pages/Staff.jsx';

export default function App() {
    return (
        <>
            <Sidebar />
            <Routes>
                <Route path="/"                  element={<Dashboard />} />
                <Route path="/prisoners"         element={<Prisoners />} />
                <Route path="/prisoners/add"     element={<AddPrisoner />} />
                <Route path="/punishments"       element={<Punishments />} />
                <Route path="/punishments/add"   element={<AddPunishment />} />
                <Route path="/visitors"          element={<Visitors />} />
                <Route path="/visitors/add"      element={<AddVisitor />} />
                <Route path="/visits"            element={<Visits />} />
                <Route path="/visits/add"        element={<AddVisit />} />
                <Route path="/staff"             element={<Staff />} />
            </Routes>
        </>
    );
}
